using System;

namespace HtmlParser
{
	/// <summary>
	/// Description r�sum�e de HtmlValue.
	/// </summary>
	public class HtmlValue
	{
		private string				_sValue;
		private int					_iPosition;
		private int					_iLength;
		

		public HtmlValue(string value, System.Int32 position, System.Int32 length)
		{
			this._sValue = value;
			this._iPosition = position;
			this._iLength = length;
		}

		public string Value
		{
			get { return this._sValue; }
		}

		public System.Int32 Position
		{
			get { return this._iPosition; }
		}

		public System.Int32 Length
		{
			get { return this._iLength; }
		}

        public override string ToString()
        {
            return this.Value;
        }


	}
}
