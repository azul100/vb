using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Net;

//using System.Diagnostics;

namespace HtmlParser
{
	/// <summary>
	/// D�finit un document html
	/// </summary>
	public class HtmlDocument
    {
        #region Membres statiques - Cr�ation d'un document

        /// <summary>
        /// Cr�e un document � partir d'une URI
        /// </summary>
        public static HtmlDocument CreateDocument(Uri uri)
        {
            return new HtmlDocument(uri);
        }

        #endregion Membres statiques - Cr�ation d'un document

        #region Champs internes

        protected Uri           _oUri           = null;
        protected string        _sInnerHtml     = null;

        protected HtmlTag[]     _oTags          = null;
        protected HtmlValue[]   _oValues        = null;
        protected HtmlNode      _oRootNode      = null;

        protected const int     PROGRESS_PERCENT_STEP = 10;

        #endregion Champs internes

        #region Constructeurs

        /// <summary>
        /// Cr�e un document � partir d'une URI
        /// </summary>
        protected HtmlDocument(Uri uri) 
		{
            WebRequest oRequest = null;
            WebResponse oResponse = null;

            // Cr�ation de la requ�te
            try
            {
                oRequest = WebRequest.Create(uri); // Exception si incorrect
            }
            catch (Exception ex)
            {
                throw new ApplicationException("L'URI est incorrecte");
            }

            // Ex�cution de la requ�te
            try
            {
                oResponse = oRequest.GetResponse();   // Exception si 404
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Impossible d'acc�der � la ressource");
            }

            // Lecture du contenu
            using (StreamReader oReader = new StreamReader(oResponse.GetResponseStream()))
            {
                this._sInnerHtml = oReader.ReadToEnd();
                oReader.Close();
            }

            // Enregistrement du chemin
            this._oUri = uri;

        }

        #endregion Constructeurs

        #region Interface publique - Construction du document
        public void LoadDocument()
        {
            // Analyse de la structure
            this.extractTags();
            this.buildTree();
        }
        #endregion Interface publique - Construction du document

        #region Interface publique - Acc�s au contenu

        /// <summary>
        /// Obtient le code html du document
        /// </summary>
		public string InnerHtml
		{
			get	{ return this._sInnerHtml; }
		}

        /// <summary>
        /// Obtient tous les tags du document
        /// </summary>
		public HtmlTag[] Tags
		{
            get { return this._oTags; }
		}

        /// <summary>
        /// Obtient le premier noeud
        /// </summary>
        public HtmlNode RootNode
        {
            get { return this._oRootNode; }
        }

		/// <summary>
        /// Obtient les tags � partir de leur nom
        /// </summary>
        /// <param name="name"> Nom des tags � trouver (ne tient pas compte de la case) </param>
		public HtmlTag[] GetTagsByName(string name)
		{
			// Pr�paration de la recherche
			string sTagName = name.ToLower();
            List<HtmlTag> oRetTags = new List<HtmlTag>();

			// Extraction des �l�ments
			foreach (HtmlTag oTag in this._oTags)
				if (name.Equals(oTag.Name.ToLower()))
					oRetTags.Add(oTag);

			// Retoure des tags trouv�s
			return oRetTags.ToArray();
        }

        #endregion Interface publique - Acc�s au contenu

        #region Interface publique - Acc�s aux r�f�rences

        /// <summary> Retourne tous les r�f�rences des images du document</summary>
		public string[] GetImageReferences()
		{
            return this.GetReferences("img", "src");
		}
		/// <summary> Retourne tous les r�f�rences des scripts du document</summary>
        public string[] GetScriptReferences()
		{
            return this.GetReferences("script", "src");
		}

		/// <summary> Retourne tous les r�f�rences des images du document</summary>
        public string[] GetLinkTagReferences()
		{
            return this.GetReferences("link", "href");
		}

		/// <summary> Retourne tous les r�f�rences des images du document</summary>
		public string[] GetAnchorReferences()
		{
            return this.GetReferences("a", "href");
		}

		/// <summary> Retourne tous les r�f�rences (href) du document</summary>
		public string[] GetReferences()
		{
            return this.GetReferences("*", "href");
		}

        /// <summary> Retourne tous les r�f�rences du document</summary>
        /// <param name="tagName"> Nom des tags � s�lectionner. * vaut pour tous les tags </param>
        /// <param name="attributeName"> Nom de l'attribut r�f�rence </param>
        public string[] GetReferences(string tagName, string attributeName)
        {
            const string ALL_NAMES = "*";

            List<string> oReferences = new List<string>();
            
			// Pour toutes les balises
			foreach(HtmlTag oTag in this._oTags)
			{
                // Si bon tag ou tous les tags
				if (oTag.Name.ToLower().Equals(tagName) || tagName.Equals(ALL_NAMES))
				{
                    HtmlAttribute oAttribute = oTag[attributeName];
					if (oAttribute != null)
					{
						string sRef = oAttribute.Value.ToLower().Replace("\"", string.Empty);
						if (!oReferences.Contains(sRef))
							oReferences.Add(sRef);
					}
				}
			}
			// Retoure des r�f�rences trouv�s
            return oReferences.ToArray();
        }

		#endregion Interface publique - obtention des r�f�rences

        #region Evenement publique - Chargement du document

        public delegate void HtmlLoadEventHandler(object sender, HtmlLoadEventArgs e);

        public class HtmlLoadEventArgs : EventArgs
        {
            private int _iPercentDone;
            private HtmlLoadingCurrentActionEnum _eCurrentAction;

            public HtmlLoadEventArgs(int percentDone, HtmlLoadingCurrentActionEnum currentAction)
            {
                this._iPercentDone = percentDone;
                this._eCurrentAction = currentAction;
            }
            public int PercentDone
            {
                get { return this._iPercentDone; }
            }
            public HtmlLoadingCurrentActionEnum CurrentAction
            {
                get { return this._eCurrentAction; }
            }
        }

        public enum HtmlLoadingCurrentActionEnum
        {
            None = 0,
            ExtractingTags = 1,
            BuildingStructure = 2
        }

        public event HtmlLoadEventHandler Loading;

        protected void onLoading(HtmlLoadEventArgs e)
        {
            if (this.Loading != null)
                this.Loading(this, e);
        }

        #endregion Evenement publique - Chargement du docuement

        #region Membres internes - Analyse du document

        /// <summary>
        /// Extrait la collection de tags et de valeurs du docuement
        /// </summary>
		protected void extractTags()
		{
            // Pr�paration de la progression
            int iCurrentPercent = 0;
            int iLastPercent = 0;

			// Pr�partation de l'analyse
			int			iLength		= this.InnerHtml.Length;					// Nombre de caract�res dans la page html
			char[]		iChars		= this.InnerHtml.ToCharArray(0, iLength);	// Caract�res de la page html
			string		sTagValue	= string.Empty;								// Valeur en cours du tag
			int			pTagStart	= 0;										// Pointe le caract�re en cours
			int			iTagLength	= 0;										// Nombre de caract�re de l'�l�ment en cours
			bool		bIsInString = false;									// True si pChar est dans une chaine
			bool		bIsInRemark = false;									// True si pchar est dans un commentaire
            List<HtmlTag>   oTags   = new List<HtmlTag>();						// Liste des tages
            List<HtmlValue> oValues = new List<HtmlValue>();					// Liste des valeurs

			// Analyse du contenu
			for (int pChar = 0; pChar < iLength; pChar++)
			{
                // Gestion de la progression
                iCurrentPercent = (pChar * 100 / iLength) / 2;
                if (iCurrentPercent > iLastPercent + PROGRESS_PERCENT_STEP)
                {
                    this.onLoading(new HtmlLoadEventArgs(iCurrentPercent, HtmlLoadingCurrentActionEnum.ExtractingTags));
                    iLastPercent = iCurrentPercent;
                }

				if (bIsInRemark)					// Si dans un commentaire html
				{
					if (iChars[pChar] == '>')			// Si fin de commentaire (-->)
						if (pChar > 2 && iChars[pChar - 1] == '-' && iChars[pChar - 2] == '-' ) // Si fin de commentaire
							bIsInRemark = false;			// Fin de la remark
					iTagLength++;						// Un caract�re de plus
				}
				else if (bIsInString)				// Si dans une chaine
				{
					if (iChars[pChar] == '"')			// Si guillement de fermeture
						bIsInString = false;				// Fin de la chaine
					iTagLength++;						// Un caract�re de plus
				}
				else								// Si dans le code html
				{
					switch (iChars[pChar])
					{
						case '<':
							sTagValue = this.InnerHtml.Substring(pTagStart, iTagLength).Trim();
							if (sTagValue.Length > 0)
							{
								//Debug.WriteLine("VAL: '" + sTagValue + "'");
                                HtmlValue oValue = new HtmlValue(sTagValue, pTagStart, iTagLength);
                                oValues.Add(oValue);
                                if (oTags.Count > 0)
                                    oTags[oTags.Count - 1].Value = oValue;

							}
							pTagStart = pChar;
							iTagLength = 1;
							//bIsInTag = true;
							break;
						case '>':
							iTagLength++;
							//bIsInTag = false;
							sTagValue = this.InnerHtml.Substring(pTagStart, iTagLength).Trim();
							if (sTagValue.Length > 0)
							{
								//Debug.WriteLine("TAG: '" + sTagValue + "'");
								oTags.Add(new HtmlTag(sTagValue, pTagStart, iTagLength));
							}
							pTagStart = pChar + 1;
							iTagLength = 0;
							break;
						case '!': // <!--
							if (pChar > 1 && pChar < iLength - 3)
								if (iChars[pChar - 1] == '<' && iChars[pChar + 1] == '-' && iChars[pChar + 2] == '-')
									bIsInRemark = true;
							iTagLength++;
							break;
						case '"':
							iTagLength++;
							bIsInString = true;
							break;
						default:
							iTagLength++;
							break;
					}
				}
			}

			// Enregistrement des tags et des valeurs
			this._oTags = oTags.ToArray();
            this._oValues = oValues.ToArray();

            // Gestion de la progression
            this.onLoading(new HtmlLoadEventArgs(50, HtmlLoadingCurrentActionEnum.None));
		}

        /// <summary>
        /// Cr�e la structure du document � partir des tags et des valeurs
        /// </summary>
		protected void buildTree()
		{
            // Pr�paration de la progression
            int iCurrentPercent = 50;
            int iLastPercent = 50;

			// Initialisation
			int pLevel = 0;
			int pTag = 0;
			int iTagCount = this._oTags.Length;
			
			// Cr�ation du node document
			this._oRootNode = new HtmlNode();
			
			// Cr�ation de la pile
            List<HtmlNode> oStack = new List<HtmlNode>();
            oStack.Add(this._oRootNode);

			// Pour chaque tag du document
			for (pTag = 0; pTag < iTagCount; pTag++)
			{

                // Gestion de la progression
                iCurrentPercent = (pTag * 100 / iTagCount) / 2 + 50;
                if (iCurrentPercent > iLastPercent + PROGRESS_PERCENT_STEP)
                {
                    this.onLoading(new HtmlLoadEventArgs(iCurrentPercent, HtmlLoadingCurrentActionEnum.BuildingStructure));
                    iLastPercent = iCurrentPercent;
                }


				// Lecture du node � ajouter
				HtmlNode oNode = new HtmlNode(this._oTags[pTag]);

				// Lecture et enregistrement du type
				HtmlTag.TypeEnum eType = HtmlTag.getTagType(oNode.Name);
				this._oTags[pTag].TagType = eType;

				// Lecture du tag de pile en cours
				HtmlNode oStackNode = oStack[pLevel];
				string s = oStackNode.Name;

				/*
				if (oNode.Tag.IsCloseTag)
					{ for (int i = 0; i < pLevel - 1; i++) Debug.Write("  "); Debug.WriteLine("/"+oNode.Name); }
				else
					{ for (int i = 0; i < pLevel - 0; i++) Debug.Write("  "); Debug.WriteLine(oNode.Name); }
				*/

				// Si tag de fermeture
				if (oNode.Tag.IsCloseTag)
				{

					// Si identique au tag en cours
					if (oNode.Name.ToLower().Equals(oStackNode.Name.ToLower()))
					{
						oStack.RemoveAt(pLevel--);				// Depilage vers le niveau pr�c�dent
						//oStackNode = oStack[pLevel];// 
						//oStackNode.Add(oNode);				// Ajout au parent
					}
					else
					{
						// Recherche du node le plus proche
						HtmlNode oCutStackNode = null;
						int pCutLevel = pLevel;
						for (; pCutLevel >= 0; pCutLevel--)
						{
							if (oStack[pCutLevel].Name.ToLower().Equals(oNode.Name.ToLower()))
							{
								oCutStackNode = oStack[pCutLevel];
								break;
							}
						}

						// Si trouv�
						if (oCutStackNode != null)
						{
							while (pCutLevel <= pLevel)	// Mise � jour de la pile		
								oStack.RemoveAt(pLevel--);

						}
						// Si non trouv�
						else
						{
							oNode.IsError = true;
							oStackNode.Add(oNode);
						}
					}
				}

				// Si tag d'ouverture ou seul
				else
				{
					// Seule ou fermeture facultative
					if (eType == HtmlTag.TypeEnum.Alone || eType == HtmlTag.TypeEnum.Closable)
					{
						oStackNode.Add(oNode);	// Ajout au parent
					}
					// Si fermeture obligatoire
					else if(eType == HtmlTag.TypeEnum.MustClose)
					{
						oStackNode.Add(oNode);	// Ajout au parent
						oStack.Add(oNode);		// Ajout dans la pile
						pLevel++;				// Niveau suivant
					}
					else
					{
						oStackNode.Add(oNode);
					}
				}
				/*
				for (int i = 0; i < pLevel; i++) Debug.Write("  ");
					Debug.WriteLine(oTag.Name);
				*/
			}

            // Gestion de la progression
            this.onLoading(new HtmlLoadEventArgs(100, HtmlLoadingCurrentActionEnum.None));

			//Debug.WriteLine(this._sInnerHtml);
        }

        #endregion Membres internes - Analyse du document

        #region Interface Publique  - Acc�s au contenu par niveau

        //public void logTree()
        //{
        //    this.logNode(this._oNodes, 0);
        //}

        //private void logNode(HtmlNode node, int level)
        //{
        //    for (int i = 0; i < level; i++) Debug.Write("  ");
        //        Debug.WriteLine(node.Name);
        //    level++;
        //    foreach(HtmlNode oNode in node.Nodes)
        //        logNode(oNode, level);
        //    level--;


        //}

		#endregion M�thodes publiques - Debug
	}
}
