using System;

namespace HtmlParser
{
	/// <summary>
	/// D�finit un attribut de tag.
	/// </summary>
	public class HtmlAttribute
	{
		private string _sName;
		private string _sValue;

		public HtmlAttribute(string name, string value)
		{
			this._sName = name;
			this._sValue = value;
		}

		public string Name
		{
			get { return this._sName; }
		}

		public string Value
		{
			get { return this._sValue; }
		}

        public override string ToString()
        {
            return string.Format("{0} = {1}", this._sName, this._sValue);
        }

	}
}
