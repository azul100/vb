using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace HtmlParser
{
	/// <summary>
	/// Repr�sent un tag HTML.
	/// </summary>
	public class HtmlTag
	{

		#region Membres statiques - Gestion du type de tag

		public enum TypeEnum
		{
			Unknow		= 0,
			Alone		= 1,
			MustClose	= 2,
			Closable	= 3
		}


		private static int		_iColCount;
		private static string[] _sBuffer;

		static HtmlTag()
		{	//(1 seule, 2 fermeture obligatoire, 3 fermture facultative)

			_iColCount = 2;
			_sBuffer = new string[]
			{	/* nom du tag	contenant		*/
				"!doctype",		"1",
				"a",			"2",
				"abbr",			"2",
				"acronym",		"2",
				"address",		"2",
				"applet",		"2",
				"area",			"1",
				"b",			"2",
				"base",			"1",
				"basefont",		"3",
				"bdo",			"2",
				"big",			"2",
				"blockquote",	"2",	
				"body",			"2",
				"br",			"1",
				"button",		"2",
				"caption",		"2",
				"center",		"2",
				"cite",			"2",
				"code",			"2",
				"col",			"1",
				"colgroup",		"2",
				"dd",			"3",
				"del",			"2",
				"dfn",			"2",
				"dir",			"2",
				"div",			"2",
				"dl",			"2",
				"dt",			"3",
				"em",			"2",
				"fieldset",		"2",
				"font",			"2",
				"form",			"2",
				"frame",		"2",
				"frameset",		"2",
				"h1",			"2",
				"h2",			"2",
				"h3",			"2",
				"h4",			"2",
				"h5",			"2",
				"h6",			"2",
				"head",			"2",
				"hr",			"1",
				"html",			"2",
				"i",			"2",
				"iframe",		"2",
				"img",			"1",
				"input",		"1",
				"ins",			"1",
				"isindex",		"1",
				"kbd",			"2",
				"label",		"2",
				"legend",		"2",
				"li",			"3",
				"link",			"2",
				"map",			"2",
				"menu",			"2",
				"meta",			"3",
				"noframes",		"2",
				"noscript",		"2",
				"object",		"2",
				"ol",			"2",
				"optgroup",		"2",
				"option",		"3",
				"p",			"2",
				"param",		"2",
				"pre",			"2",
				"q",			"2",
				"s",			"2",
				"samp",			"2",
				"script",		"2",
				"select",		"2",
				"small",		"2",
				"span",			"2",
				"strike",		"2",
				"strong",		"2",
				"style",		"2",
				"sub",			"2",
				"sup",			"2",
				"table",		"2",
				"tbody",		"2",
				"td",			"2",
				"textarea",		"2",
				"tfoot",		"2",
				"th",			"2",
				"thead",		"2",
				"title",		"2",
				"tr",			"2",
				"tt",			"2",
				"u",			"2",
				"ul",			"2",
				"var",			"2"
			};

		}

		public static TypeEnum getTagType(string name)
		{
			string sName = name.ToLower();
			for (int i = 0; i < _sBuffer.Length; i+=_iColCount)
				if (_sBuffer[i].Equals(sName))
					return (TypeEnum)int.Parse(_sBuffer[i+1]);
			/*
					switch (int.Parse(_sBuffer[i+1]))
					{
						case (int)TypeEnum.alone:		return TypeEnum.alone;
						case (int)TypeEnum.mustClose:	return TypeEnum.mustClose;
						case (int)TypeEnum.closable:	return TypeEnum.closable;
						default:						return TypeEnum.unknow;
					}
			*/
			return TypeEnum.Unknow;
		}

		#endregion Membres statiques - Gestion du type de tag

		#region Membres statiques

		private static Regex  REGEX_DUMMYCHARS = new Regex(@"[\f\n\r\t\v]");

		#endregion Membres statiques

		#region Champs priv�s

		private string				_sInnerHtml;
		private int					_iPosition;
		private int					_iLength;
	
		private string				_sName;
		private HtmlTag.TypeEnum	_eType;
		private bool				_bIsCloseTag;
		private HtmlAttribute[]		_oAttributes;
        private HtmlValue           _oValue;

		#endregion Champs priv�s

		#region Constructeurs

		public HtmlTag(string innerHtml, System.Int32 position, System.Int32 length)
		{
			//
			this._sInnerHtml	= REGEX_DUMMYCHARS.Replace(innerHtml, string.Empty);
			this._iPosition		= position;
			this._iLength		= length;
			this._sName			= null;
			this._oAttributes	= null;
			this._eType			= TypeEnum.Unknow;
			// 
			this.defineAttributes();
			this.defineType();
		}

		#endregion Constructeurs

		#region M�thode priv�s - Analyse du code html

		private void defineAttributes()
		{
			// Pr�paration de la recherche
			int iLength = this.InnerHtml.Length;
			char[] iChars = this.InnerHtml.ToCharArray(0, iLength);
			bool bIsInString = false;
			int  pAttributeStart = 0;
			int  iAttributeLength = 0;
			char[] sValueSeparator = new char[]{'='};
			
			string sTagValue;
			List<HtmlAttribute> oAttributes = null;

			//
			for (int pChar = 0; pChar < iLength; pChar++)
			{
				if (bIsInString)
				{
					if (iChars[pChar] == '"')
					{
						bIsInString = !bIsInString;
						iAttributeLength++;
					}
					else
					{
						iAttributeLength++;
					}
					
				}
				else
				{
					switch (iChars[pChar])
					{
						case '<':
							pAttributeStart = pChar + 1;
							break;
						case ' ':
						case '>':
							sTagValue = this.InnerHtml.Substring(pAttributeStart, iAttributeLength).Trim();
							if (sTagValue.Length > 0)
							{
								//Debug.WriteLine("  ATTR: '" + sTagValue + "'");
								if (this._sName == null)
								{
									this._sName = sTagValue;
								}
								else
								{
									if (oAttributes == null)
                                        oAttributes = new List<HtmlAttribute>();
									string[] sAttributeItems =  sTagValue.Split(sValueSeparator, 2);
									string sAttributeName = sAttributeItems[0];
									string sAttributeValue = (sAttributeItems.Length > 1)? sAttributeItems[1].Replace(">", string.Empty): null;
									oAttributes.Add(new HtmlAttribute(sAttributeName, sAttributeValue));
								}
							}
							pAttributeStart = pChar;
							iAttributeLength = 1;
							//bIsInTag = true;
							break;
						case '"':
							iAttributeLength++;
							bIsInString = true;
							break;
						default:
							iAttributeLength++;
							break;
					}
				}
			}

			if (oAttributes != null)
				this._oAttributes = oAttributes.ToArray();
		}



		private void defineType()
		{
			this._bIsCloseTag = false;

			// Si tag de fermeture
			if (this._sName.Substring(0,1).Equals("/"))
			{
				this._bIsCloseTag = true;
				this._sName = this._sName.Substring(1);
			}
			/*
				// Si tag d'information
			else if (this._sName.Substring(0,1).Equals("!"))
			{
				this._sName = this._sName.Substring(1);
			}
			*/
		}

		#endregion Analyse du code html

		#region Interface publique - Accesseurs

		public string InnerHtml
		{
			get { return this._sInnerHtml; }
		}

		public System.Int32 Position
		{
			get { return this._iPosition; }
		}
		public System.Int32 Length
		{
			get { return this._iLength; }
		}

		public string Name
		{
			get { return this._sName; }
		}

		public System.Boolean IsCloseTag
		{
			get { return this._bIsCloseTag; }
		}

		public HtmlTag.TypeEnum TagType
		{
			get { return this._eType; }
			set
			{
				if (this._eType != TypeEnum.Unknow)
					throw new InvalidOperationException("TagType est d�ja d�fini");
				this._eType = value;
			}
		}

		public HtmlAttribute[] Attributes
		{
			get { return this._oAttributes; }
		}
		public HtmlAttribute this[string name]
		{
			get
			{
				string sName = name.ToLower();
				if (this._oAttributes != null)
					foreach (HtmlAttribute oAttribute in this._oAttributes)
						if (sName.Equals(oAttribute.Name.ToLower()))
							return oAttribute;
				return null;
			}
		}

        public HtmlValue Value
        {
            get { return this._oValue; }
            set { this._oValue = value; }
        }

		#endregion Interface publique - Accesseurs
	
		#region Interface publique - M�thodes

		public string GetValue(string attributeName)
		{
			string sAttributeName = attributeName.ToLower();
			foreach (HtmlAttribute oAttribute in this._oAttributes)
				if (sAttributeName.Equals(oAttribute.Name.ToLower()))
					return oAttribute.Value;
			return null;
		}

		#endregion Interface publique - M�thodes
	

	}
}
