Parser html-----------
Url     : http://codes-sources.commentcamarche.net/source/41034-parser-htmlAuteur  : thiosyiasarDate    : 20/08/2013
Licence :
=========

Ce document intitul� � Parser html � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Ce code est une lib qui permet d'acc&eacute;der la structure d'une page HTML
<b
r />
<br />Sa tol&eacute;rance sur la qualit&eacute; du code HTML est certes in
f&eacute;rieur aux navigateurs mais suffisent pour la plupart des applis ou je l
'ai utilis&eacute;
<br /><a name='source-exemple'></a><h2> Source / Exemple : <
/h2>
<br /><pre class='code' data-mode='basic'>
(tout est dans le zip)
</pre
>
<br /><a name='conclusion'></a><h2> Conclusion : </h2>
<br />Bientot quand 
le html sera bien format&eacute;, on pourra utiliser un parseur xml mais pour l'
instant... n'h&eacute;sitez par &agrave; le tester et a me faire parvenir l'url 
des pages qui mettre ce code a genoux :(
