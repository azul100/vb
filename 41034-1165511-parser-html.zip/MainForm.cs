using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace HtmlParser
{
    public partial class MainForm : Form
    {
        #region Membres internes

        private HtmlDocument _oHtmlDocument = null;
        private Dictionary<TreeNode, HtmlNode> _oNodeDico = new Dictionary<TreeNode, HtmlNode>();

        #endregion Membres internes

        #region Constructeurs

        public MainForm()
        {
            InitializeComponent();
            this.txtUri.Text = "http://www.google.fr";
        }

        #endregion Membres internes

        #region Lancement du chargement

        private void txtUri_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
                this.btnLoad_Click(this, new EventArgs());
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            // Cr�ation de l'adresse saisie 
            string sUri = this.txtUri.Text.Trim();

            // Chargement
            Uri oUri = null;
            if (Uri.TryCreate(sUri, UriKind.Absolute, out oUri))
            {
                HtmlDocument.HtmlLoadEventHandler oLoadingEventHandler = null;
                try
                {
                    this._oHtmlDocument = HtmlDocument.CreateDocument(oUri);

                    // Initialisation de la progression
                    this.InitLoading();

                    // Cr�ation de la structure
                    oLoadingEventHandler = new HtmlDocument.HtmlLoadEventHandler(HtmlDocument_Loading);
                    this._oHtmlDocument.Loading += oLoadingEventHandler;
                    this._oHtmlDocument.LoadDocument();
                    this.LoadStructure(this.tvwStructure, this._oHtmlDocument);
                }
                catch (ApplicationException ex)
                {
                    MessageBox.Show(ex.Message, "Erreur de chargement", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    this._oHtmlDocument.Loading -= oLoadingEventHandler;
                }
            }
            else
            {
                MessageBox.Show("V�rifiez l'URI saisie", "Erreur de saisie", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }

        #endregion Lancement du chargement

        #region Affichage de la structure

        /// <summary>
        /// Ajout des premiers nodes
        /// </summary>
        private void LoadStructure(TreeView treeView, HtmlDocument document)
        {
            TreeNodeCollection oNodes = treeView.Nodes;
            oNodes.Clear();

            // Ajout des nodes
            foreach (HtmlNode oHtmlNode in document.RootNode.Nodes)
                this.AddNode(oHtmlNode, oNodes, this._oNodeDico);
        }

        /// <summary>
        /// Ajout des nodes enfants
        /// </summary>
        private void tvwStructure_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {
            TreeNodeCollection oNodes = e.Node.Nodes;

            // Si nodes par encore charg�
            if (oNodes.Count == 1 && !this._oNodeDico.ContainsKey(oNodes[0]))
            {
                oNodes.Clear();
                HtmlNode oSelectedHtmlNode = this._oNodeDico[e.Node];

                // Ajout des nodes
                foreach (HtmlNode oHtmlNode in oSelectedHtmlNode.Nodes)
                    this.AddNode(oHtmlNode, oNodes, this._oNodeDico);

            }
        }

        /// <summary>
        /// Ajout du node au treeview
        /// </summary>
        private void AddNode(HtmlNode htmlnode, TreeNodeCollection treeNodes, IDictionary<TreeNode, HtmlNode> dico)
        {
            TreeNode oTreeNode = new TreeNode(htmlnode.Tag.InnerHtml);
            treeNodes.Add(oTreeNode);
            oTreeNode.Nodes.Add("(chargement...)");
            dico.Add(oTreeNode, htmlnode);
        }

        /// <summary>
        /// Affichage du d�tails du node
        /// </summary>
        private void tvwStructure_AfterSelect(object sender, TreeViewEventArgs e)
        {
            this.propertyGrid1.SuspendLayout();
            this.propertyGrid1.SelectedObject = (e.Node == null || !this._oNodeDico.ContainsKey(e.Node)) ? null : this._oNodeDico[e.Node].Tag;
            this.propertyGrid1.ResumeLayout(true);
        }

        #endregion Gestion de la progression du chargement

        #region Gestion de la progression du chargement

        private void InitLoading()
        {
            this.lblStatus.Visible = true;
            this.lblStatus.Text = "Chargement en cours....";
            this.prgStatus.Visible = true;
            this.prgStatus.Minimum = 0;
            this.prgStatus.Maximum = 100;
            this.prgStatus.Value = 0;

            this.Refresh();
            Application.DoEvents();
        }


        private void HtmlDocument_Loading(object sender, HtmlDocument.HtmlLoadEventArgs e)
        {
            if (e.PercentDone == 100)
            {
                this.lblStatus.Text = "Ok";
                this.prgStatus.Visible = false;
            }
            else
            {
                this.lblStatus.Text = e.CurrentAction.ToString();
                this.prgStatus.Visible = true;
                this.prgStatus.Value = e.PercentDone;
            }
        }

        #endregion Gestion de la progression du chargement
    }
}
