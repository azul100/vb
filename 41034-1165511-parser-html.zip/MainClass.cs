using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace HtmlParser
{
	/// <summary>
	/// Description r�sum�e de MainClass.
	/// </summary>
	public class MainClass
	{
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            MainForm oForm = new MainForm();
            Application.Run(oForm);
        }
	}
}
