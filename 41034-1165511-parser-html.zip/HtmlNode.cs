using System;
using System.Collections.Generic;

namespace HtmlParser
{
    /// <summary>
    /// Repr�sente un �l�ment de structure du DOM
    /// </summary>
	public class HtmlNode
	{
		List<HtmlNode>	_oChildNodes;
		string		_sName;
		HtmlTag		_oTag;
		bool		_bIsError;

		
		public HtmlNode()
		{
			this.commonConstructor(null);
		}
		
		public HtmlNode(HtmlTag tag)
		{
			this.commonConstructor(tag);
		}

		private void commonConstructor(HtmlTag tag)
		{
			if (tag != null)
			{
				this._sName = tag.Name;
				this._oTag = tag;
			}
			else
			{
				this._sName = string.Empty;
				this._oTag = null;
			}
            this._oChildNodes = new List<HtmlNode>();
			this._bIsError = false;
		}

		public string Name
		{
			get { return this._sName; }
		}

		public HtmlTag Tag
		{
			get { return this._oTag; }
		}

		public HtmlNode[] Nodes
		{
			get { return this._oChildNodes.ToArray(); }
		}

		public void Add(HtmlNode childNode)
		{
			this._oChildNodes.Add(childNode);
		}

		/*
		public void Add(HtmlNode[] childNodes)
		{
			foreach (HtmlTag oChildTag in childTags)
				this._oChildNodes.Add(new HtmlNode(oChildTag));
		}
		*/

		public System.Boolean IsError
		{
			get { return this._bIsError; }
			set { this._bIsError = value; }
		}

		public override string ToString()
		{
			return this._sName;
		}



	}

	
}
