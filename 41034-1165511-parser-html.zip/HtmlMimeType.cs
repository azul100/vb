using System;

namespace HtmlParser
{
	/// <summary>
	/// Gestion des Types Mime.
	/// </summary>
	public class HTMLMimeType
	{
		private HTMLMimeType() { }

		/// <summary>
		/// Retourne le type mime de l'extension de fichier pass�e
		/// Retourne null si l'extension n'est pas g�r�e
		/// </summary>
		public static string GetMimeType(string extension)
		{
			// Suppression du point et mise en minuscule
			string sExt = extension.Replace(".", String.Empty).ToLower();

			//
			if (sExt.Equals("avi"))		return "video/avi";
			if (sExt.Equals("bmp"))		return "image/bmp";
			if (sExt.Equals("doc"))		return "application/msword"; 
			if (sExt.Equals("dot"))		return "application/msword"; 
			if (sExt.Equals("eps"))		return "application/postscript";
			if (sExt.Equals("gif"))		return "image/gif"; 
			if (sExt.Equals("htm"))		return "text/html"; 
			if (sExt.Equals("html"))	return "text/html"; 
			if (sExt.Equals("htmls"))	return "text/html"; 
			if (sExt.Equals("ico"))		return "image/x-icon";
			if (sExt.Equals("jpe"))		return "image/jpeg"; 
			if (sExt.Equals("jpeg"))	return "image/jpeg";
			if (sExt.Equals("jpg"))		return "image/jpeg";
			if (sExt.Equals("mp3"))		return "audio/mp3";
			if (sExt.Equals("mpa"))		return "audio/mpeg";
			if (sExt.Equals("mpe"))		return "video/mpeg";
			if (sExt.Equals("mpeg"))	return "video/mpeg";
			if (sExt.Equals("mpg"))		return "video/mpeg";
			if (sExt.Equals("mpga"))	return "audio/mpeg";
			if (sExt.Equals("pdf"))		return "application/pdf";
			if (sExt.Equals("pps"))		return "application/mspowerpoint";
			if (sExt.Equals("ppt"))		return "application/mspowerpoint";
			if (sExt.Equals("ps"))		return "application/postscript";
			if (sExt.Equals("rt"))		return "text/richtext";
			if (sExt.Equals("rtf"))		return "application/rtf";
			if (sExt.Equals("scm"))		return "video/x-scm";
			if (sExt.Equals("shtml"))	return "text/html";
			if (sExt.Equals("swf"))		return "application/x-shockwave-flash";
			if (sExt.Equals("txt"))		return "text/plain";
			if (sExt.Equals("tif"))		return "image/tiff";
			if (sExt.Equals("tiff"))	return "image/tiff";
			if (sExt.Equals("vrml"))	return "model/vrml";
			if (sExt.Equals("vsd"))		return "application/x-visio";
			if (sExt.Equals("vst"))		return "application/x-visio";
			if (sExt.Equals("vsw"))		return "application/x-visio";
			if (sExt.Equals("wml"))		return "text/vnd.wap.wml";
			if (sExt.Equals("word"))	return "application/msword";
			if (sExt.Equals("wri"))		return "application/mswrite";
			if (sExt.Equals("wrl"))		return "x-world/x-vrml";
			if (sExt.Equals("wrz"))		return "model/vrml";
			if (sExt.Equals("xla"))		return "application/excel";
			if (sExt.Equals("xls"))		return "application/excel";

			//
			return null;
		}
	}
}



