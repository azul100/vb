using System;

namespace HtmlParser
{
	/// <summary>
	/// Table de convertion HTML.
    /// ( A titre d'incation, non utilis� dans ce projet)
	/// </summary>
	public static class HtmlChars
	{
		private static string[] _sBuffer;

		static HtmlChars()
		{
			_sBuffer = new string[]
			{
				/*	Caract�res sp�cifiques :				*/
				//"&nbsp;",	" ",	/* (ins�cable)			*/
				"&amp;",	"&",	/* & commercial			*/
				"&euro;",	"�",	/* euro					*/
				"&pound;",	"�",	/* livre sterling		*/
				"&yen;",	"�",	/* Yen					*/
				"&quot;",	"\\",	/* double quote			*/ 
				"&copy;",	"�",	/* copyright			*/
				"&ccedil;", "�",	/* C cedille			*/ 
				"&reg;",	"�",	/* register				*/
				//"&larr;",	"",		/* ???? les fl�ches		*/
				"&sect;",	"�",	/* Paragraphe			*/ 
				"&para;",	"�",	/* Paragraphe			*/ 
				"&iquest;", "�",	/* ? invers�			*/
				"&raquo;",	"�",	/* double fleche droite	*/ 
				"&laquo;",	"�",	/* double fleche gauche	*/ 
				/*	Les accents :							*/
				"&Aacute;",	"�",	/* Lettre A				*/				
				"&aacute;",	"�",	/*						*/
				"&Acirc;",	"�",	/*						*/
				"&acirc;",	"�",	/*						*/
				"&agrave;",	"�",	/*						*/
				"&eacute;",	"�",	/* Lettre E				*/
				"&ecirc;",	"�",	/*						*/
				"&egrave;",	"�",	/*						*/
				"&ocirc;",	"�",	/* Lettre O				*/ 
				"&ouml;",	"�",	/*						*/
				/*	Caract�res math�matiques :				*/ 
				"&deg;",	"�",	/* degr�				*/ 
				"&permil;",	"�",	/* Pour mille			*/ 
				"&prime;",	"'",	/* Prime 				*/
				//"&Prime;",	"?",	/* Seconde				*/
				//"&infin;",	"8",	/* Infini				*/
				"&plusmn;",	"�",	/* Plus ou Moins		*/
				"&lt;",		"<",	/* inf�rieur �			*/
				"&gt;",		">",	/* sup�rieur �			*/
				"&frac14;",	"�",	/* fraction 1/4			*/
				"&frac12;",	"�",	/* fraction 1/2			*/
				"&frac34;",	"�",	/* fraction 3/4			*/
				"&sup1;",	"�",	/* Puissance 1			*/
				"&sup2;",	"�",	/* Puissance 2			*/
				"&sup3;",	"�",	/* Puissance 3			*/
				/*	Lettres greques :						*/
				//"&alpha;","a",	/* Alpha				*/
				"&beta;",	"�",	/* Beta					*/
				//"&chi;",	"?",	/* Chi					*/
				//"&psi;",	"?",	/* Psi					*/
				"&Omega;",	"O",	/* Grand Omega			*/
				//"&omega;","?"		/* Petit Omega			*/
			};

		}
	}
}
